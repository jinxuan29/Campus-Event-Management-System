package view;

public class SettingsPageView extends PageView {

}

package view;

public class ReportsPageView extends PageView {

}

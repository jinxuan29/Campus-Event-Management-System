package view;

public class RegistrationsPageView extends PageView {

}

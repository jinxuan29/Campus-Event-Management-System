package model;

public class Seminars {

}
